export interface Post {
    id: number
    content: string
    createdAt: string
    thread: string
    isFromBot: boolean
  }