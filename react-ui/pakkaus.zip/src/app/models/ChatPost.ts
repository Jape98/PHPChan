export interface ChatPost {
    id: number;
    createdAt: Date;
    userId: number;
    userName: string;
    content: string;
    
}