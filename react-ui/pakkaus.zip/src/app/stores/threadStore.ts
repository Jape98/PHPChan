import { makeAutoObservable, runInAction } from "mobx";
import agent from "../api/agent";
import { Thread, ThreadPostValues } from "../models/Thread";

export default class ThreadStore {
    threads: Thread[] = [];
    threadRegistry = new Map<string, Thread>();
    selectedThread: Thread | undefined = undefined;
    editMode = false;
    threadToBeVieved: Thread | undefined = undefined;

    constructor() {
        makeAutoObservable(this)
    }

    loadThreads = async () => {
        try {
            var thread = await agent.Threads.list();
            runInAction(() => {this.threads = thread;})
            
        } catch (error) {
            runInAction(() => {console.log(error)})
        }
        
    }

    addNewThread = async (creds:ThreadPostValues) => {
        try {
            return "";

        } catch (error) {
            throw error;
            return "";
        }
    }

    loadThread = async (id: string) => {
        let thread = this.getThread(id);
        if (thread) {
            runInAction(() => this.selectedThread = thread);
            return thread;
        } else {
            try{
                thread = await agent.Threads.details(id);

                this.setThread(thread!);
                this.selectedThread = thread;
                return thread;
            }catch (error){
                console.log(error)
            }
        }
    }

    setThreadToBeVieved(thread: Thread){
        this.threadToBeVieved = thread;
    }

    getThreadToBeVieved(){
        return this.threadToBeVieved;
    }

    private getThread = (id: string) => {
        return this.threadRegistry.get(id);
    }

    private setThread = (thread: Thread) => {
        this.threadRegistry.set(thread.id, thread)
    }

    clearSelecterThread= () => {
        runInAction(() => this.selectedThread = undefined);
    }
}